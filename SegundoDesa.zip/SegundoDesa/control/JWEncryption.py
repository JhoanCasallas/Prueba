from jwcrypto import jwk, jwe
import datetime
import pytz
import json

class JWEncryption(object):
    def __init__(self, iat=None, encryptedJWE=None, decryptedJWE=None):
        self.iat = iat
        self.encryptedJWE = encryptedJWE
        self.decryptedJWE = decryptedJWE

    
    def dateUnix(self):
        dt = datetime.datetime.now(pytz.utc)
        self.iat = int((dt - datetime.datetime(1970, 1, 1, tzinfo=pytz.utc)).total_seconds())
        return self.iat
    
    def encryptJWE(self, payload):
        try:
            # with open("./certificate/public_key.pem", "rb") as publicfile:
            with open("public_key.pem", "rb") as publicfile:
                pkeydata = publicfile.read()

            public = jwk.JWK.from_pem(pkeydata)

            protected_header = {
                "iat": self.dateUnix(),
                "alg": "RSA-OAEP-256",
                "enc": "A256GCM",
                "kid": public.thumbprint(),
            }

            jwetoken = jwe.JWE(payload.encode("utf-8"),
                               recipient=public,
                               protected=protected_header)
            
            enc = jwetoken.serialize()

            d = json.loads(enc)

            self.encryptedJWE = d.get("protected")+"."+d.get("encrypted_key")+"."+d.get("iv")+"."+d.get("ciphertext")+"."+d.get("tag")

            print(self.encryptedJWE)
        
        except Exception as exc:
            print(exc)