import sys
from control.JWEncryption import JWEncryption

if __name__ == '__main__':
    try:
        parametro = sys.argv[1]
        encryption = JWEncryption()
        encryption.encryptJWE(parametro)
    except Exception as e:
        print('ERROR encryption: ' + e)